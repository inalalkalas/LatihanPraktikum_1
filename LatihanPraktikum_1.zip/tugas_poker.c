#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void printArray(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        char card[3];
        switch (arr[i]) {
            case 10:
                strcpy(card, "10");
                break;
            case 11:
                strcpy(card, "J");
                break;
            case 12:
                strcpy(card, "Q");
                break;
            case 13:
                strcpy(card, "K");
                break;
            default:
                sprintf(card, "%d", arr[i]);
        }
        printf("%s ", card);
    }
    printf("\n");
}

int minExchangeSteps(int *cards, int n, int *steps) {
    int step = 0;
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (cards[j] < cards[minIndex])
                minIndex = j;
        }
        if (minIndex != i) {
            swap(&cards[i], &cards[minIndex]);
            steps[step++] = i + 1;
            printf("Langkah %d: ", step);
            printArray(cards, n);
        }
    }
    return step;
}

int main() {
    int n;
    scanf("%d", &n);

    int *cards = (int*)malloc(n * sizeof(int));

    for (int i = 0; i < n; i++) {
        char input[3];
        scanf("%s", input);

        switch (input[0]) {
            case '1':
                cards[i] = 10;
                break;
            case 'J':
            case 'j':
                cards[i] = 11;
                break;
            case 'Q':
            case 'q':
                cards[i] = 12;
                break;
            case 'K':
            case 'k':
                cards[i] = 13;
                break;
            default:
                cards[i] = input[0] - '0';
        }
    }

    int *step = (int*)malloc(n * sizeof(int)); // Inisialisasi array langkah
    printf("Langkah-langkah penataan kartu:\n");
    int numSteps = minExchangeSteps(cards, n, step);
    printf("\nJumlah perubahan: %d\n", numSteps);

    free(cards);
    free(step);

    return 0;
}
